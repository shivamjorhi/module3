package Lab1.B;



import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("spring2.xml");
		Employee emp = context.getBean("emp1", Employee.class);
		SBU sbu = context.getBean("BU", SBU.class);

		
		System.out.println("Employee details");
		System.out.println("-------------------------");
		System.out.println("Employee ID : "+emp.getEmployeeId());
		System.out.println("Employee Name : "+emp.getEmployeeName());
		System.out.println("Employee Salary : "+emp.getSalary());
		System.out.println("Employee Age : "+emp.getAge());
		System.out.println("--------------------------");
		System.out.println("SBU details");
		System.out.println("--------------------------");
		System.out.println("SBU Id : "+emp.getBU().getSbuId());
		System.out.println("SBU Name : "+emp.getBU().getSbuName());
		System.out.println("SBU Head : "+emp.getBU().getSbuHead());

	}

}
