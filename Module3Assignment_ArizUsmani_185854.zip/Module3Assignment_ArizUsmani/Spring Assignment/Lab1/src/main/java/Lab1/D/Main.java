package Lab1.D;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import Lab1.D.Employee;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("spring4.xml");
		
		BufferedReader read=new BufferedReader(new InputStreamReader(System.in));
		
		
		Service service=new Service();
		System.out.print("Employee ID : ");
        int eid=Integer.parseInt(read.readLine());
		Employee e2=service.getAll(eid);
		if(e2!=null)
		{
			System.out.println("Employee Info :");
			System.out.println("Employee ID     : "+e2.getEmployeeId());
			System.out.println("Employee NAME   : "+e2.getEmployeeName());
			System.out.println("Employee SALARY : "+e2.getSalary());
		}
		else
		{
			System.out.println("No employee found"); 
			
		}

	}

}
