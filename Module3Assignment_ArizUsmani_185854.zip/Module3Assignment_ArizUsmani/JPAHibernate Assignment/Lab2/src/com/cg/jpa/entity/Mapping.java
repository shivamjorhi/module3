package com.cg.jpa.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="mapping")
public class Mapping {

	@Id
	private int sno;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Author author;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Book book;

	public int getSno() {
		return sno;
	}

	public void setSno(int sno) {
		this.sno = sno;
	}

	public Author getAuthor() {
		return author;
	}

	public void setAuthor(Author author) {
		this.author = author;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	public Mapping() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Mapping(int sno, Author author, Book book) {
		super();
		this.sno = sno;
		this.author = author;
		this.book = book;
	}
}
