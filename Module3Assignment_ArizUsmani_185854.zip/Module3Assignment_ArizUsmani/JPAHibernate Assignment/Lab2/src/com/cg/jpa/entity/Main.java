package com.cg.jpa.entity;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		
		Mapping m=new Mapping();
		Book b=new Book();
		Author a=new Author();
		
		/*
		em.getTransaction().begin();                //Adding data
		
		m.setSno(1);
		b.setTitle("HarryPotter");
		b.setPrice(700.00);
	    a.setName("JKRowling");
		m.setBook(b);
		m.setAuthor(a);
		
		m.setSno(2);
		b.setTitle("2States");
		b.setPrice(100.00);
		a.setName("ChetanBhagat");
		m.setBook(b);
		m.setAuthor(a);
		
		em.persist(m);
		em.getTransaction().commit();
		*/
		
		Query q4=em.createQuery("select b from Book b");      //Operation1
		List<Book> lst2=q4.getResultList();
		
		for(Book y:lst2) {
			System.out.println(" ISBN="+y.getISBN()+" Title="+y.getTitle()+" Price="+y.getPrice());
		}
		
		
		Query q=em.createQuery("select a.ID from Author a where a.name=:b");   //Operation2
		q.setParameter("b", "JKRowling");
		int l=(int)q.getSingleResult();
		//System.out.println(l);
		Query q2=em.createQuery("select m.book.ISBN from Mapping m where m.author.ID=:c");
		q2.setParameter("c", l);
		int l2=(int)q2.getSingleResult();
		//System.out.println(l2);
		Query q3=em.createQuery("select b.title from Book b where b.ISBN=:d");
		q3.setParameter("d", l2);
		String l3=(String)q3.getSingleResult();
		System.out.println(l3);
		
		Query q7=em.createQuery("select b from Book b where b.price between :g and :h");     //Operation3
		q7.setParameter("g", 500.00);
	    q7.setParameter("h", 1000.00);
		List<Book> lst3=q7.getResultList();
		for(Book z:lst3) {
			System.out.println(z.getTitle());
		}
		
		Query q5=em.createQuery("select m.author.ID from Mapping m where m.book.ISBN=:e");   //Operation4
		q5.setParameter("e", 46);
		int l4=(int)q5.getSingleResult();
		Query q6=em.createQuery("select a.name from Author a where a.ID=:f");
		q6.setParameter("f", l4);
		String l5=(String)q6.getSingleResult();
		System.out.println(l5);
	
	}
}
